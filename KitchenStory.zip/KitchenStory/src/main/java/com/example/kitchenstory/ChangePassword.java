package com.example.kitchenstory;



import com.example.kitchenstory.Database.Dao;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;


@WebServlet("/ChangePassword")
public class ChangePassword extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try {

            Dao dataBase = new Dao();
            HttpSession session = request.getSession();
            if (dataBase.changeAdminPassword(email, password)) {
                session.setAttribute("message", "Password Changed Successfully");
            } else {
                session.setAttribute("message", "Error!  Enter Valid Email & Password");

            }
        } catch (ClassNotFoundException | SQLException e) {

            e.printStackTrace();
        }
        response.sendRedirect("changePassword.jsp");
    }
}
