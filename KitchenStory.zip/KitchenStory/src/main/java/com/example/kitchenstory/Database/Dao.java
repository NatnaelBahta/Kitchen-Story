package com.example.kitchenstory.Database;



import com.example.kitchenstory.Model.Foods;
import com.example.kitchenstory.Model.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


/*
                  To connect to MySql Database JDBC (Hibernate, JPA)
1, Register the Driver -> Class.forName(String className)throws ClassNotFoundException
2, Create connection ->  Connection con = DriverManager.getConnection(String url,String name,String password) throws SQLException
3, Create statement  ->  Statement st = con.createStatement();
4, Execute queries   ->  ResultSet rs = st.executeQuery(query);
5, Close connection  ->  con.close();
*/

public class Dao {
    public Connection con = null;
    public Statement st = null;

    public Dao() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.cj.jdbc.Driver");
//        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/KitchenStory", "root", "nathnael");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/KitchenStory", "root", "nathnael");
        System.out.println("connection established with database");

        st = con.createStatement();
    }


    // Method to search all available foods
    public List<Foods> searchFoods(String BuyFood) {

        List<Foods> foodsList = new ArrayList<Foods>();

//    String query = "SELECT * FROM KitchenStory.food where name='" + name + "'";

        String query = "SELECT * FROM KitchenStory.food WHERE name";


        try {
            ResultSet result = st.executeQuery(query);

            while (result.next()) {

                Integer food_id = result.getInt("food_id");
                String name = result.getString("name");
                String type= result.getString("type");


                Foods foodsDetail = new Foods(food_id, name, type);
                foodsList.add(foodsDetail);

                return foodsList;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Method to check user login
    public User validateUser(String email, String password) {
        User loginUser = null;
        String query = "select * from user where email='" + email + "' and password='" + password + "'";
        try {
            ResultSet result = st.executeQuery(query);
            if (result.next()) {
                String userEmail = result.getString("email");
                String userPassword = result.getString("password");
                String userName = result.getString("full_name");
                loginUser = new User(userEmail, userPassword, userName);
            }

            return loginUser;
        } catch (SQLException e) {

            e.printStackTrace();
        }

        return loginUser;
    }

    // Method to add user into user table
    public boolean insertUser(User user) {
        try {
            PreparedStatement state = con.prepareStatement("insert into user " + "(email, password, full_name, dob, phn) values (?,?,?,?,?)");

            state.setString(1, user.getEmail());
            state.setString(2, user.getPassword());
            state.setString(3, user.getName());
            state.setString(4, user.getDateOfBirth());
            state.setString(5, user.getPhoneNumber());

            state.executeUpdate();
            return true;
        } catch (SQLException e) {

            e.printStackTrace();
        }
        return false;
    }

    // Method to check admin
    public boolean validateAdmin(String email, String password) {

        try {
            ResultSet result = st.executeQuery("select * from admin where email='" + email + "' and password='" + password + "'");
            if (result.next())
                return true;
        } catch (SQLException e) {

            e.printStackTrace();
        }
        return false;
    }

    // Method to Change Password
    public boolean changeAdminPassword(String email, String password) {

        try {
            ResultSet result = st.executeQuery("select * from admin where email='" + email + "'");
            if (!result.next()) {
                return false;
            }
            st.execute("update admin set password='" + password + "' where email='" + email + "'");
            return true;
        } catch (SQLException e) {

            e.printStackTrace();
        }
        return false;
    }

    // Method to Add food
    public boolean addFood(Foods fli) {
        try {
            PreparedStatement stat = con
                    .prepareStatement("insert into foods" + "(food_id, name, type) values (?,?,?)");

            stat.setInt(1, fli.getFood_id());
            stat.setString(2, fli.getName());
            stat.setString(3, fli.getType());

            stat.executeUpdate();
            return true;
        } catch (SQLException e) {

            e.printStackTrace();
            return false;
        }
    }



}

