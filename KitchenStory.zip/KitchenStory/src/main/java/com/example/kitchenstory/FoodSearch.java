package com.example.kitchenstory;


import com.example.kitchenstory.Database.Dao;
import com.example.kitchenstory.Model.Foods;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/FoodSearch")
public class FoodSearch extends HttpServlet {

    private static final long serialVersionUID = 1L;


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String movieName = request.getParameter("foodName");


        try {

            Dao dataBase = new Dao();

            List<Foods> foodsList = dataBase.searchFoods(movieName);
            HttpSession session = request.getSession();
            session.setAttribute("foods", foodsList);
        } catch (ClassNotFoundException | SQLException e) {

            e.printStackTrace();
        }
        response.sendRedirect("foodsList.jsp");
    }
}
