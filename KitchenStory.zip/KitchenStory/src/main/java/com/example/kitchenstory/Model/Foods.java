package com.example.kitchenstory.Model;

public class Foods {

    private Integer food_id;
    private String name;
    private String type;

    public Foods(Integer food_id, String name, String type) {
        this.food_id = food_id;
        this.name = name;
        this.type = type;
    }

    public Integer getFood_id() {
        return food_id;
    }

    public void setFood_id(Integer food_id) {
        this.food_id = food_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
