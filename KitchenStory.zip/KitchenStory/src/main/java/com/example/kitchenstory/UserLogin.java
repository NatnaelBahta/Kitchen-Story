package com.example.kitchenstory;


import com.example.kitchenstory.Database.Dao;
import com.example.kitchenstory.Model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;


@WebServlet("/UserLogin")
public class UserLogin extends HttpServlet {
    private static final long serialVersionUID = 1L;


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try {
            Dao dataBase = new Dao();


            User user = dataBase.validateUser(email, password);
            HttpSession session = request.getSession();

            if (user != null) {
                session.setAttribute("user", user);
                response.sendRedirect("homePage.jsp");
            } else {
                session.setAttribute("message", "Error!  Enter Valid Email & Password");
                response.sendRedirect("homePage.jsp");
            }
        } catch (ClassNotFoundException | SQLException e) {

            e.printStackTrace();
        }
    }
}
