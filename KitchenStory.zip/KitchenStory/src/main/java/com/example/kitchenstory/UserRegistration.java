package com.example.kitchenstory;


import com.example.kitchenstory.Database.Dao;
import com.example.kitchenstory.Model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;



import java.io.IOException;
import java.sql.SQLException;




@WebServlet("/UserRegistration")
public class UserRegistration extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String name = request.getParameter("full_name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String dob = request.getParameter("dob");
        String phn = request.getParameter("phn");
        User user = new User(email, password, name, dob, phn);

        try {
            Dao dataBase = new Dao();

            boolean result = dataBase.insertUser(user);
            HttpSession session = request.getSession();
            if (result) {
                session.setAttribute("message", "User Added Successfully! Please Login");
            } else {
                session.setAttribute("message", "Error! Please Enter Again Valid Input");
            }
        } catch (ClassNotFoundException | SQLException e) {

            e.printStackTrace();
        }
        response.sendRedirect("userLogin.jsp");
    }

}
