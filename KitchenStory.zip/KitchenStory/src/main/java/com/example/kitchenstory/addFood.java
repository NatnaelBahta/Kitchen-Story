package com.example.kitchenstory;


import com.example.kitchenstory.Database.Dao;
import com.example.kitchenstory.Model.Foods;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/addFood")
public class addFood extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Integer food_id = request.getIntHeader("food_id");
        String name = request.getParameter("name");
        String type = request.getParameter("type");

        Foods fli = new Foods(food_id, name, type);

        try {
            Dao dataBase = new Dao();

            HttpSession session = request.getSession();
            if (dataBase.addFood(fli)) {
                session.setAttribute("message", "Food Added Successfully");
            } else {
                session.setAttribute("message", "Error! Please Enter Valid Input");
            }
        } catch (ClassNotFoundException | SQLException e) {

            e.printStackTrace();
        }
        response.sendRedirect("addFood.jsp");
    }
}
